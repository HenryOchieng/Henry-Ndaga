var loader = document.getElementById('preloader');

window.addEventListener ("load", function() {
    //Hide the spinner after  seconds
setTimeout(function(){loader.style.display = 'none';}, 3000);

});